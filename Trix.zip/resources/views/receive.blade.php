<div class = "left message">
    <img src="" alt ="">
    <p>{{$message}}</p>
</div>
