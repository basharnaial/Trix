<div class = "right message">
    <p>{{$message}}</p>
    <img src="" alt ="">
</div>
